module ProjectBAD {
	opens view;
	opens model;
	requires javafx.graphics;
	requires javafx.controls;
	requires javafx.base;
	requires java.sql;
	requires jfxtras.labs;
	
	
}